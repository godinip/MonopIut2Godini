import Diagramme_de_packages.*;

public class IHM {

	Controleur controleur;

	/**
	 * 
	 * @param j
	 */
	public void messageEtatJouer(Joueur j) {
		// TODO - implement IHM.messageEtatJouer
		throw new UnsupportedOperationException();
	}

}