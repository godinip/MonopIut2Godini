package Diagramme_de_packages;

public class Controleur {

	IHM ihm;
	Monopoly monopoly;

	/**
	 * 
	 * @param j
	 */
	public void jouerUnCoup(Joueur j) {
		// TODO - implement Controleur.jouerUnCoup
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param j
	 */
	private Carreau lancerDésAvancer(Joueur j) {
		// TODO - implement Controleur.lancerDésAvancer
		throw new UnsupportedOperationException();
	}

	public int lancerDés() {
		// TODO - implement Controleur.lancerDés
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param s
	 */
	public Carreau getCarreau(int s) {
		// TODO - implement Controleur.getCarreau
		throw new UnsupportedOperationException();
	}

}