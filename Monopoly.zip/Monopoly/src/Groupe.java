import java.util.*;
import Diagramme_du_domaine.*;

public class Groupe {

	private Collection<ProprieteAConstruire> proprietesdugroupe;
	private CouleurPropriete couleur;

}