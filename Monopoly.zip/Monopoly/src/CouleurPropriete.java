public enum CouleurPropriete {
	bleuFonce, orange, mauve, violet, bleuCiel, jaune, vert, rouge
}