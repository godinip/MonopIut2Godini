package Diagramme_du_domaine;

public class AutreCarreau extends Carreau {
}