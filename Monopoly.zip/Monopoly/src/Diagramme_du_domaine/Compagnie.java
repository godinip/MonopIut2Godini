package Diagramme_du_domaine;

public class Compagnie extends Propriete {
}