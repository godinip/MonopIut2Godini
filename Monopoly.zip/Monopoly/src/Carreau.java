public abstract class Carreau {

	private int numero;
	private String nomCarreau;

	public int getNumero() {
		return this.numero;
	}

}