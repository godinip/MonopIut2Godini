import java.util.*;

public class Monopoly {

	private Carreau carreaux;
	private Collection<Joueur> joueurs;

}