import Diagramme_du_domaine.*;

public class Gare extends Propriete {

	/**
	 * 
	 * @param j
	 */
	private void acheterPropriete(Joueur j) {
		// TODO - implement Gare.acheterPropriete
		throw new UnsupportedOperationException();
	}

}